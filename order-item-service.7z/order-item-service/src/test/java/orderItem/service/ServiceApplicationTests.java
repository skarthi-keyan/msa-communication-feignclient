package orderItem.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceApplicationTests {


}
