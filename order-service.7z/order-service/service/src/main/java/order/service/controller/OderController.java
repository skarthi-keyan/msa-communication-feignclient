package order.service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import order.service.model.OrderModel;
import order.service.model.OrderRepository;

@RestController
@RequestMapping(path="/display")
public class OderController {
	@Autowired
	private OrderRepository employeeData;
	
	@RequestMapping(path = "/getAll", method = RequestMethod.GET)
	public List<OrderModel>  employees() {
		return  employeeData.findAll();

	}
	@RequestMapping(path = "/welcome", method = RequestMethod.GET)
	public String  hello() {
		return  "Welcome hi";

	}

}
